$(document).ready(function () {
    $(".menu-top-icon").click(function () {
        $(".black").removeClass("noDisplay");
        $(".right-nav").addClass("wider");
        $(".right-nav-top").removeClass("noDisplay");
        $(".right-menu-itemset").removeClass("noDisplay");
    });
    $(".black").click(function () {
        $(".black").addClass("noDisplay");
        $(".right-nav").removeClass("wider");
        $(".right-nav-top").addClass("noDisplay");
        $(".right-menu-itemset").addClass("noDisplay");
    });
});
