$(document).ready(function () {
    $("#loginbtn").click(function () {
        var username = $("#username").val();
        var password = $("#password").val();
        $.ajax
        ({
            type:"POST",
            url:'http://test.tahviehjavid.com/login.php',
            dataType:"json",
            data:{
                loginid:username,
                loginpass:password
            },
            cache: false,
            success:function (result) {

                if (result.status == "نام کاربری یا کلمه عبور صحیح نیست"){
                    $(".black").removeClass("noDisplay");
                    $(".popup").removeClass("noDisplay");
                }
                else{
                    window.localStorage.setItem("loggedIn", 1);
                    window.localStorage.setItem("username", result.result);
                    window.location.href="dashboard.html";
                }
            }
        });
    });
    $(".closebtn").click(function () {
        $(".black").addClass("noDisplay");
        $(".popup").addClass("noDisplay");
    })
});

