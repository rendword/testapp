$(document).ready(function () {
    //show cart
    var cartUser = window.localStorage.getItem("username");
    $.ajax
    ({
        type: "POST",
        url: 'http://test.tahviehjavid.com/displaycart.php',
        dataType: "json",
        data: {
            cartUser: cartUser
        },
        cache: false,
        success: function (result) {
            var x =1;
            var sum = 0;
            var currentBox = "<table class='customTable'><tr><th>نام کالا</th><th>شناسه</th><th>قیمت</th><th>تعداد</th><th></th></tr>";
            while (typeof(result[("ans" + x)]) != "undefined" && result[("ans" + x)] !== null){
                var currentId= result['ans' + x].id,
                    currentPname = result['ans' + x].productname,
                    currentPid = result['ans' + x].productid,
                    currentPprices = result['ans' + x].price,
                    currentPcounter = result['ans' + x].counter;
                currentBox += "<tr><td>"+currentPname+"</td><td>"+currentPid+"</td><td>"+currentPprices+"</td><td>"+currentPcounter+"</td><td><button class='deleteCart' id='"+currentId+"'>حذف</button></td></tr>" ;
                sum+=Number(currentPprices);
                x++;
            }
            currentBox+= "<tr><td class='tableBorderTop' colspan='2'>جمع کل</td><td class='tableBorderTop' colspan='2'>"+sum+"<span>تومان</span></td></tr></table>";
            console.log(sum);
            $(".showCartItem").html(currentBox);
        }
    });
});
$(document).on("click",".deleteCart",function () {
    var deletecartkey = $(this).attr("id");
    $(".blackpop").removeClass("noDisplay");
    $("#confirmDelete").removeClass("noDisplay");
    $(document).on("click","#decline",function () {
        $(".blackpop").addClass("noDisplay");
        $("#confirmDelete").addClass("noDisplay");
    });
    $(document).on("click","#confirm",function () {
        $.ajax
        ({
            type: "POST",
            url: 'http://test.tahviehjavid.com/deletecart.php',
            dataType: "json",
            data: {
                deletecartkey: deletecartkey
            },
            cache: false,
            success: function (result) {
                location.reload(true);
            }
        });
    });
});