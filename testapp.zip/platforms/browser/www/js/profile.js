$(document).ready(function () {
    var profileUser = window.localStorage.getItem("username");
    $.ajax
    ({
        type: "POST",
        url: 'http://test.tahviehjavid.com/getprofile.php',
        dataType: "json",
        data: {
            profileUser: profileUser
        },
        cache: false,
        success: function (result) {
            var x = 1;
            var currentBox = "";
            while (typeof(result[("ans" + x)]) != "undefined" && result[("ans" + x)] !== null) {
                var fname = result['ans' + x].fname,
                    lname = result['ans' + x].lname,
                    phone = result['ans' + x].phone,
                    uid = result['ans' + x].uid,
                    password = result['ans' + x].password,
                    usertype = result['ans' + x].usertype,
                    comname = result['ans' + x].comname,
                    aphone = result['ans' + x].aphone,
                    radiovar = "<span>نوع کاربری : </span><input id='comm' type='radio' name='usertype'><span>تجاری</span><input id='notcomm' type='radio' name='usertype'><span>غیر تجاری</span>"
                $("#fname").val(fname);
                $("#lname").val(lname);
                $("#phone").val(phone);
                $("#uid").val(uid);
                $("#password").val(password);
                $(".radioparts").html(radiovar);
                $("#comname").val(comname);
                $("#aphone").val(aphone);
                if (usertype == 1) {
                    $("#comm").prop("checked", true);
                }
                if (usertype == 2) {
                    $("#notcomm").prop("checked", true);
                }
                x++;
            }

        }
    });
    $("#updateBtn").click(function () {
        var fnamet = $("#fname").val(),
            lnamet = $("#lname").val(),
            phonet = $("#phone").val(),
            uidt = $("#uid").val(),
            passwordt = $("#password").val(),
            comnamet = $("#comname").val(),
            aphonet = $("#aphone").val();
        if ($("#comm").prop("checked")) {
            var usertypet = 1
        }
        if ($("#notcomm").prop("checked")) {
            var usertypet = 2
        }
        $.ajax
        ({
            type: "POST",
            url: 'http://test.tahviehjavid.com/updateuser.php',
            dataType: "json",
            data: {
                fnamet: fnamet,
                lnamet: lnamet,
                phonet: phonet,
                uidt: uidt,
                passwordt: passwordt,
                comnamet: comnamet,
                aphonet: aphonet,
                usertypet: usertypet
            },
            cache: false,
            success: function (result) {
                if (result.mass == "مشخصات با موفقیت بروزرسانی شد") {
                    $(".popupMessage").html(result.mass)
                    $(".blackpop").removeClass("noDisplay");
                    $(".popup").removeClass("noDisplay");
                }
                else {
                    $(".popupMessage").html(result.mass)
                    $(".blackpop").removeClass("noDisplay");
                    $(".popup").removeClass("noDisplay");
                }

            }
        });
    });
    $(".closeRegisterPopup").click(function () {
        $(".blackpop").addClass("noDisplay");
        $(".popup").addClass("noDisplay");
    });
});

