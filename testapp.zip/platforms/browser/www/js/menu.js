$(document).ready(function () {
    var thisUser = window.localStorage.getItem("username");
    $.ajax
    ({
        type: "POST",
        url: 'http://test.tahviehjavid.com/getlastname.php',
        dataType: "json",
        data: {
            thisUser: thisUser
        },
        cache: false,
        success: function (result) {
            var lname = result.lastname;
            window.localStorage.setItem("lastname", lname);
            var thisLastName = window.localStorage.getItem("lastname");
            console.log(thisLastName)
        }
    });
    $(".menu-top-icon").click(function () {
        $(".black").removeClass("noDisplay");
        $(".right-nav").addClass("wider");
        $(".right-nav-top").removeClass("noDisplay");
        $(".right-menu-itemset").removeClass("noDisplay");
    });
    $(".black").click(function () {
        $(".black").addClass("noDisplay");
        $(".right-nav").removeClass("wider");
        $(".right-nav-top").addClass("noDisplay");
        $(".right-menu-itemset").addClass("noDisplay");
    });
});
