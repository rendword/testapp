$(document).ready(function () {
    //show products
    var buy = "test";
    $.ajax
    ({
        type: "POST",
        url: 'http://localhost/kaveh/controllers/displayproducts.php',
        dataType: "json",
        data: {
            buy: buy
        },
        cache: false,
        success: function (result) {
            var x =1;
            var currentBox = "";
            while (typeof(result[("ans" + x)]) != "undefined" && result[("ans" + x)] !== null){
                var currentID = result['ans' + x].productid,
                    currentPname = result['ans' + x].productname,
                    currentPCap = result['ans' + x].productcap,
                    currentPDetails = result['ans' + x].productdetails,
                    currentPType = result['ans' + x].producttype,
                    currentPrice = result['ans' + x].price,
                    currentPicture = result['ans' + x].picture;
                    currentBox += "<div id='"+currentID+"' class='generalProductBox'><div class='productImageBox'><img class='productImage' src='"+currentPicture+"' alt=''></div><div class='leftPart'><div class='textPart'><span class='productTitle'>"+currentPname+"</span><br><span class='productCaption'>"+currentPCap+"</span></div><hr><span class='priceTag'>"+currentPrice+"</span><span class='priceTag'>تومان</span><br><button id='viewSingle' class='redBtn'>مشاهده</button><button id='addToCart' class='redBtn'>سفارش</button></div></div>";
                x++;
        }
        $(".productBox").html(currentBox);
        }
    });
    // view single product
    $(document).on("click","#viewSingle",function () {
        $(".blackpop").removeClass("noDisplay");
        $(".singleProduct").removeClass("noDisplay");
        var idkey = $(this).parents(".generalProductBox").attr("id");
        $.ajax
        ({
            type: "POST",
            url: 'http://localhost/kaveh/controllers/singleproduct.php',
            dataType: "json",
            data: {
                idkey: idkey
            },
            cache: false,
            success: function (result) {
                var x =1;
                var currentSingle = "";
                while (typeof(result[("ans" + x)]) != "undefined" && result[("ans" + x)] !== null){
                    var currentID = result['ans' + x].productid,
                        currentPname = result['ans' + x].productname,
                        currentPCap = result['ans' + x].productcap,
                        currentPDetails = result['ans' + x].productdetails,
                        currentPType = result['ans' + x].producttype,
                        currentPrice = result['ans' + x].price,
                        currentPicture = result['ans' + x].picture;
                    currentSingle += "<div><img src='"+currentPicture+"' alt=''></div><h4 id='prodcutNameS'>"+currentPname+"<h6 id='productIdS'>"+currentID+"</h6><h5 id='productCapS'>"+currentPCap+"</h5><h5 id='productDetS'>"+currentPDetails+"</h5><h6><span id='productPriceS'>"+currentPrice+"</span><span>تومان</span></h6><button id='singleOrderBtn' class='redBtn'>سفارش</button><button id='closeSingleProduct' class='redBtn'>بستن</button>";
                    x++;
                }
                $(".singleProduct").html(currentSingle);
            }
        });
        //hide single product
        $(".blackpop").click(function () {
            $(".blackpop").addClass("noDisplay");
            $(".singleProduct").addClass("noDisplay");
        });
        $(document).on("click","#closeSingleProduct",function () {
            $(".blackpop").addClass("noDisplay");
            $(".singleProduct").addClass("noDisplay");
        });
        //confirm add to cart
        $(document).on("click","#singleOrderBtn",function () {
            $(".blackpoptwo").removeClass("noDisplay");
            $(".confirmAddToCart").removeClass("noDisplay");
        });
        $(document).on("click","#confirmCart",function () {
            var sendPName = $(this).parent('.confirmAddToCart').siblings('.singleProduct').children('#prodcutNameS').text(),
                sendPId = $(this).parent('.confirmAddToCart').siblings('.singleProduct').children('#productIdS').text(),
                sendPPrice = $(this).parent('.confirmAddToCart').siblings('.singleProduct').find('#productPriceS').text();
            $.ajax
            ({
                type: "POST",
                url: 'http://localhost/kaveh/controllers/cart.php',
                dataType: "json",
                data: {
                    sendPName: sendPName,
                    sendPId:sendPId,
                    sendPPrice:sendPPrice,
                    pageCookie:pageCookie
                },
                cache: false,
                success: function (result) {
                    alert(result.newappmsg)
                }
            });
        });

    })
    });