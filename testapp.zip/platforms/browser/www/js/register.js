$(document).ready(function () {
    //remove red parts on type
    $("#commercial").click(function () {
        $(".radio").removeClass("warningBorder");
    });
    $("#notcommercial").click(function () {
        $(".radio").removeClass("warningBorder");
    });
    $('#firstname').on('keyup', function() {
        if (this.value.length > 0) {
            $("#firstname").removeClass("warningColor");
            $("#firstname").removeClass("warningBorder");
        }
    });
    $('#lastname').on('keyup', function() {
        if (this.value.length > 0) {
            $("#lastname").removeClass("warningColor");
            $("#lastname").removeClass("warningBorder");
        }
    });
    $('#mobilenumber').on('keyup', function() {
        if (this.value.length > 0) {
            $("#mobilenumber").removeClass("warningColor");
            $("#mobilenumber").removeClass("warningBorder");
        }
    });
    $('#userid').on('keyup', function() {
        if (this.value.length > 0) {
            $("#userid").removeClass("warningColor");
            $("#userid").removeClass("warningBorder");
        }
    });
    $('#userpass').on('keyup', function() {
        if (this.value.length > 0) {
            $("#userpass").removeClass("warningColor");
            $("#userpass").removeClass("warningBorder");
        }
    });
    //when user clicks register button
    $("#registerBtn").click(function () {
        //get values and if not typed make inputs red
        if ($("#firstname").val()){
            var firstName = $("#firstname").val()
        }
        else {
            $("#firstname").addClass("warningColor");
            $("#firstname").addClass("warningBorder");
        }
        if ($("#lastname").val()){
            var lastName = $("#lastname").val()
        }
        else {
            $("#lastname").addClass("warningColor");
            $("#lastname").addClass("warningBorder");
        }
        if ($("#mobilenumber").val()){
            var mobileNumber = $("#mobilenumber").val()
        }
        else {
            $("#mobilenumber").addClass("warningColor");
            $("#mobilenumber").addClass("warningBorder");
        }
        if ($("#userid").val()){
            var userId = $("#userid").val()
        }
        else {
            $("#userid").addClass("warningColor");
            $("#userid").addClass("warningBorder");
        }
        if ($("#userpass").val()){
            var userPass = $("#userpass").val()
        }
        else {
            $("#userpass").addClass("warningColor");
            $("#userpass").addClass("warningBorder");
        }
        if($("#commercial").is(":checked")){
            userStatus = 1;
        }
        else if ($("#notcommercial").is(":checked")){
            userStatus = 2;
        }
        else {
            $(".radio").addClass("warningBorder");
            userStatus = null;
        }
        if($("#comname").val()){
            var comName = $("#comname").val();
        }
        else {
            comName = null;
        }
        if($("#alterphone").val()){
            var alterPhone = $("#alterphone").val();
        }
        else {
            alterPhone = null;
        }
        if($("#address").val()){
            var address = $("#address").val();
        }
        else {
            address = null;
        }
        //show popup message
        if ($("#firstname").val() && $("#lastname").val() && $("#mobilenumber").val() && $("#userid").val() && $("#userpass").val() && userStatus!=null && userStatus == 0 || userStatus == 1){
            $.ajax
            ({
                type:"POST",
                url:'http://test.tahviehjavid.com/register.php',
                dataType:"json",
                data:{
                    firstName:firstName,
                    lastName:lastName,
                    mobileNumber:mobileNumber,
                    userId:userId,
                    userPass:userPass,
                    userStatus:userStatus,
                    comName:comName,
                    alterPhone:alterPhone
                },
                cache: false,
                success:function (result) {
                    $(".black").removeClass("noDisplay");
                    $(".popupRegister").removeClass("noDisplay");
                    $(".loginRegisterPopup").removeClass("noDisplay");
                    $(".popupMessage").html(result.mssg);
                }
            });
        }
        else{
            $(".black").removeClass("noDisplay");
            $(".popupRegister").removeClass("noDisplay");
            $(".closeRegisterPopup").removeClass("noDisplay");
            $(".popupMessage").html("لطفا تمام فیلدهای اجباری را پر کنید");
        }
        //remove popup message
        $(".black").click(function () {
            $(".black").addClass("noDisplay");
            $(".popupRegister").addClass("noDisplay");
            $(".closeRegisterPopup").addClass("noDisplay");
            $(".loginRegisterPopup").addClass("noDisplay");
        });
        $(".closeRegisterPopup").click(function () {
            $(".black").addClass("noDisplay");
            $(".popupRegister").addClass("noDisplay");
            $(".closeRegisterPopup").addClass("noDisplay");
            $(".loginRegisterPopup").addClass("noDisplay");
        })
    });
});